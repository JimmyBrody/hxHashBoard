$("#my-bar-10d").hover(function() {
	alert("a")
}, funtion() {
	alert("b")
})